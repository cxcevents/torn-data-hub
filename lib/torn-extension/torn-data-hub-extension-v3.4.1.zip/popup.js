const KEY_STORE = "tdh_api_key";
const FEAT_STORE = "tdh_features";
const vitalsEl = document.getElementById("vitals");

let apiKey = "";

function fmt(n) { return Number(n).toLocaleString("en-US"); }

function fmtTime(s) {
  if (s <= 0) return "0s";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  const ss = s % 60;
  if (m > 0) return `${m}m ${ss}s`;
  return `${ss}s`;
}

function bar(name, cls, cur, max) {
  const pct = max > 0 ? Math.min(100, (cur / max) * 100) : 0;
  return `
    <div class="vital">
      <div class="vital-row">
        <span class="vital-name">${name}</span>
        <span class="vital-val">${fmt(cur)}<span class="max"> / ${fmt(max)}</span></span>
      </div>
      <div class="track"><div class="fill ${cls}" style="width:${pct}%"></div></div>
    </div>`;
}

async function loadVitals() {
  if (!apiKey) {
    vitalsEl.innerHTML = `
      <div class="muted">Add your Torn API key to load vitals.</div>
      <button class="configure" id="configure">Open preferences</button>`;
    document.getElementById("configure").addEventListener("click", () => chrome.runtime.openOptionsPage());
    return;
  }
  try {
    const res = await fetch(
      `https://api.torn.com/user/?selections=bars,cooldowns&key=${apiKey}&comment=TDH-popup`
    );
    const d = await res.json();
    if (d.error) throw new Error(d.error.error);

    const cdRow = (label, secs, maxSecs) => {
      const pct = secs > 0 ? Math.max(3, ((maxSecs - Math.min(secs, maxSecs)) / maxSecs) * 100) : 100;
      return `
        <div class="cd-row">
          <span class="cd-label">${label}</span>
          ${secs > 0
            ? `<span class="cd-val">${fmtTime(secs)}</span>`
            : `<span class="cd-val ready">Ready</span>`}
        </div>
        <div class="track" style="height:5px"><div class="fill ${secs > 0 ? "cd" : "cd-done"}" style="width:${pct}%"></div></div>`;
    };

    vitalsEl.innerHTML = `
      ${bar("Energy", "energy", d.energy?.current ?? 0, d.energy?.maximum ?? 0)}
      ${bar("Nerve",  "nerve",  d.nerve?.current  ?? 0, d.nerve?.maximum  ?? 0)}
      ${bar("Happy",  "happy",  d.happy?.current  ?? 0, d.happy?.maximum  ?? 0)}
      ${bar("Life",   "life",   d.life?.current   ?? 0, d.life?.maximum   ?? 0)}
      <div class="section">
        ${cdRow("Drug Cooldown",    d.cooldowns?.drug    ?? 0,  6 * 3600)}
        ${cdRow("Booster Cooldown", d.cooldowns?.booster ?? 0, 48 * 3600)}
        ${cdRow("Med Cooldown",     d.cooldowns?.medical ?? 0,  6 * 3600)}
      </div>
      <div class="section dash-link">
        <a href="https://torn-data-hub--cxcevents.replit.app/" target="_blank" rel="noopener">Open full Torn Dashboard →</a>
      </div>
    `;
    chrome.runtime.sendMessage({ type: "tdh-refresh-icon" }).catch(() => {});
  } catch (e) {
    vitalsEl.innerHTML = `<div class="muted">⚠ ${e.message || e}</div>`;
  }
}

chrome.storage.local.get([KEY_STORE, FEAT_STORE], (v) => {
  apiKey = v[KEY_STORE] || "";
  if (v[FEAT_STORE]?.popupVitals === false) {
    vitalsEl.innerHTML = `
      <div class="muted">Popup vitals are turned off.</div>
      <button class="configure" id="configure">Open preferences</button>`;
    document.getElementById("configure").addEventListener("click", () => chrome.runtime.openOptionsPage());
    return;
  }
  loadVitals();
});

document.getElementById("gear").addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

// Version display (updates are handled by the Chrome Web Store)
document.getElementById("ver").textContent = `v${chrome.runtime.getManifest().version}`;
